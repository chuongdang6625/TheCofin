<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\ProductType;
use Illuminate\Support\Facades\Redirect;

class TypeController extends Controller
{
    public function getListProductType(){
        $productType = ProductType::all();
        return view('admin.productType.listProductType', ['productType'=>$productType]);
    }

    public function getEditProductType($productType_id){
        $productType = ProductType::find($productType_id);
        return view('admin.productType.editProductType',['productType'=>$productType]);
    }

    public function postEditProductType(Request $request, $productType_id){
        $productType = ProductType::find($productType_id);
        $this->validate(
            $request,
            [
                'txtName' => 'bail|required|min:3|max:100',
            ],
            [
                'txtName.required' => 'Bạn chưa nhập tên cho loại sản phẩm',
                'txtName.min' => 'Tên loại sản phẩm phải có độ dài từ 3 đến 100 ký tự',
                'txtName.max' => 'Tên loại sản phẩm phải có độ dài từ 3 đến 100 ký tự',
            ]
            );

            $productType->productType_name = $request->txtName;
            $productType->productType_description = $request->txtIntro;
            $productType->productType_status = $request->rdoStatus;
            $productType->parent_id = $request->txtParent;

            $productType->save();
            return redirect('admin/productType/edit'.$productType_id)->with('thongbao', 'Sửa thành công');
    }

    public function getAddProductType(){
        $list_parent = ProductType::with('getParent')->where('parent_id',null)->get();
        return view('admin.productType.addProductType',[
            'list_parent' => $list_parent,
        ]);
    }

    public function postAddProductType(Request $request){
        $this->validate(
            $request,
            [
                'txtName' => 'bail|required|unique:ProductType,productType_name|min:3|max:100',
            ],
            [
                'txtName.required' => 'Bạn chưa nhập tên thể loại',
                'txtname.unique' => 'Tên thể loại đã tồn tại',
                'txtName.min' => 'Tên thể loại phải có độ dài từ 3 đến 100 ký tự',
                'txtName.max' => 'Tên thể loại phải có độ dài từ 3 đến 100 ký tự',
            ]
            );

            $productType = new ProductType();
            $productType->productType_name = $request->txtName;
            $productType->productType_description = $request->txtIntro;
            $productType->productType_status = $request->rdoStatus;

            $productType->parent_id = $request->txtParent;
            $productType->save();
            return redirect('admin/productType/add')->with('thongbao', 'Thêm thành công');
    }

    public function getDelete($productType_id){
        $productType = ProductType::find($productType_id);
        $productType->delete();
        return redirect('admin/productType/list')->with('thongbao','Bạn đã xóa thành công');
    }
}
