<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Customer;
use Session;

class UserController extends Controller
{
    public function getUserIndex(){
        return view('user.pages.homepage');
    }

    public function getInformationUser($cust_id){
        $customer = Customer::where('id',$cust_id);
        return view('user.pages.informationUser', ['customer'=>$customer]);
    }

    public function editInformationUser(Request $request){
        $this->validate(
            $request,
            [
                'txtPass' => 'bail|required',
            ],
            [
                'txtPass.required' => 'Chưa nhập mật khẩu'
            ]
        );
        $idCust = $request->idCust;

        Customer::where('id', $idCust)
        ->update([
            'cust_name' => $request->txtHoten,
            'cust_tel' => $request->txtTel,
            'cust_email' => $request->txtEmail,
            'cust_add' => $request->txtDiachi,
            'cust_pass' => $request->txtPass
        ]);
        return back();
    }
}
