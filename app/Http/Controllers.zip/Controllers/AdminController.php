<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Admin;

class AdminController extends Controller
{
     //lay danh sach admin
     public function getListAdmin(){
        $admins = Admin::all();
        return view('admin.admin.listAdmin', compact('admins'));
    }

    //trang chinh sua thong tin admin
    public function getEditAdmin($id){
        $p = Admin::where('id', $id)->first();
        return view('', compact('p'));
    }

    //ham xu ly chinh sua thong tin admin
    public function postEditAdmmin(Request $rs, $id){
        Admin::where('id', $id)->update([
            'admin_name'=>$rs->adname,
            'admin_pass'=>bcrypt($rs->adpass),
            'admin_role'=>$rs->adrole,
            'admin_email'=>$rs->ademail,
        ]);

        return back()->with('edit_admin_success', 'Sửa thành công');
    }

    //ham delete admin
    public function deleteAd($id){
        $p = Admin::where('id', $id);
        $p->delete();
        return back()->with('delete_admin_success', 'Xóa thành công');
    }

    //chuyen den trang them admin
    public function getAddAdmin(){
        return view('admin.admin.addAdmin');
    }

    //ham xu ly them admin
    public function postAddAdmin(Request $rs){
        $admin = $rs->all();

        $admin = new Admin;
        $admin->admin_name = $rs->adname;
        $admin->admin_role = $rs->adrole;
        $admin->admin_email = $rs->ademail;
        $admin->admin_pass = bcrypt($rs->adpass);
        $admin->save();
        return back()->with('create_admin_success', 'Đã tạo thành công');
    }
}
